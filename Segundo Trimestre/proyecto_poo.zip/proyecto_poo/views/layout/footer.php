		    
				</div>

</div>
<!-- Pie de Pagina -->
<footer id="footer">
    <p>Desarrollado  por Germán &copy; en <?=date('Y')?> </p>
    
</footer>
</div>
</body>	
</html>