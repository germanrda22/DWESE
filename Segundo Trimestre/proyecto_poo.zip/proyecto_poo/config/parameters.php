<?php
//constante con el dominio de mi proyecto
define("base_url", "http://localhost/DWESE(Belen)/Segundo%20Trimestre/proyecto_poo/");

//defino el contador por defecto y el método por defecto que tengo
define("controller_default", "productoController");
define("action_default", "index");

//estas constantes de usarán cuando hagamos llamadas a imagenes en las vistas
//o a URLs del proyecto en las vistas